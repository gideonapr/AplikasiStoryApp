package com.example.aplikasistoryapp.ui.stories

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aplikasistoryapp.adapter.ListStoryAdapter
import com.example.aplikasistoryapp.adapter.LoadingStateAdapter
import com.example.aplikasistoryapp.databinding.FragmentStoriesBinding
import com.example.aplikasistoryapp.ui.create.CreateActivity
import com.example.aplikasistoryapp.utils.VMFactory

class StoryFragment : Fragment() {

    private var _binding: FragmentStoriesBinding? = null
    private val binding get() = _binding!!
    private lateinit var listStoriesAdapter: ListStoryAdapter
    private lateinit var factory: VMFactory
    private val homeViewModel: StoryVM by viewModels { factory }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentStoriesBinding.inflate(inflater, container, false)
        val root: View = binding.root

        setupViewModel()
        setupView(root.context)
        getStories()
        createStoryButtonHandler()

        return root
    }

    private fun setupViewModel() {
        factory = VMFactory.getInstance(binding.root.context)
    }

    private fun setupView(context: Context) {
        val storiesRv = binding.storiesRv

        if (context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            storiesRv.layoutManager = GridLayoutManager(context, 2)
        } else {
            storiesRv.layoutManager = LinearLayoutManager(context)
        }

        listStoriesAdapter = ListStoryAdapter()
        storiesRv.adapter = listStoriesAdapter
    }

    private fun getStories() {
        binding.storiesRv.adapter = listStoriesAdapter.withLoadStateFooter(
            footer = LoadingStateAdapter {
                listStoriesAdapter.retry()
            }
        )

        homeViewModel.getListStory.observe(viewLifecycleOwner) {
            listStoriesAdapter.submitData(lifecycle, it)
        }
    }

    private fun createStoryButtonHandler() {
        binding.createStoryButton.setOnClickListener {
            val intent = Intent(binding.root.context, CreateActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}