package com.example.aplikasistoryapp.utils

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.aplikasistoryapp.data.StoryRepository
import com.example.aplikasistoryapp.di.Injection
import com.example.aplikasistoryapp.ui.create.CreateVM
import com.example.aplikasistoryapp.ui.login.LoginVM
import com.example.aplikasistoryapp.ui.maps.MapsVM
import com.example.aplikasistoryapp.ui.register.RegisterVM
import com.example.aplikasistoryapp.ui.stories.StoryVM

class VMFactory private constructor(private val repo: StoryRepository) : ViewModelProvider.NewInstanceFactory() {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StoryVM::class.java)) {
            return StoryVM(repo) as T
        }
        if (modelClass.isAssignableFrom(LoginVM::class.java)) {
            return LoginVM(repo) as T
        }
        if (modelClass.isAssignableFrom(RegisterVM::class.java)) {
            return RegisterVM(repo) as T
        }
        if (modelClass.isAssignableFrom(CreateVM::class.java)) {
            return CreateVM(repo) as T
        }
        if (modelClass.isAssignableFrom(MapsVM::class.java)) {
            return MapsVM(repo) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
    }

    companion object {
        @Volatile
        private var instance: VMFactory? = null
        fun getInstance(context: Context): VMFactory {
            return instance ?: synchronized(this) {
                instance ?: VMFactory(Injection.provideRepository(context))
            }.also { instance = it }
        }
    }
}