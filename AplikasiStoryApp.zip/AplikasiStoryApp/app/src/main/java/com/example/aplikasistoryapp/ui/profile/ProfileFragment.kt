package com.example.aplikasistoryapp.ui.profile

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import androidx.appcompat.app.AppCompatDelegate
import androidx.datastore.preferences.preferencesDataStore
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.aplikasistoryapp.databinding.FragmentProfileBinding
import com.example.aplikasistoryapp.model.LoginModel
import com.example.aplikasistoryapp.preference.LoginPreference
import com.example.aplikasistoryapp.preference.SettingPreferences
import com.example.aplikasistoryapp.ui.login.LoginActivity
import com.example.aplikasistoryapp.viewmodel.SettingVM
import com.example.aplikasistoryapp.viewmodel.SettingVMFactory

private val Context.dataStore by preferencesDataStore(name = "settings")

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    private lateinit var loginPreference: LoginPreference
    private lateinit var loginModel: LoginModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)

        loginPreference = LoginPreference(requireContext())
        loginModel = loginPreference.getUser()

        setupUi()
        setupLanguageHandler()
        setupLogoutHandler()
        setupCurrentTheme()
        setupChangeThemeHandler()
        playAnimation()

        return binding.root
    }

    private fun setupUi() {
        binding.tvName.text = loginModel.name
        binding.tvUserId.text = loginModel.userId
    }

    private fun setupLanguageHandler() {
        binding.languageCardView.setOnClickListener {
            startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
        }
    }

    private fun setupLogoutHandler() {
        binding.logoutCardView.setOnClickListener {
            loginPreference.removeUser()
            val intent = Intent(activity, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            activity?.finish()
        }
    }

    private fun setupCurrentTheme() {
        val pref = SettingPreferences.getInstance(requireContext().dataStore)
        val settingViewModel = ViewModelProvider(this, SettingVMFactory(pref))[SettingVM::class.java]

        settingViewModel.getThemeSettings().observe(viewLifecycleOwner) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                binding.switchTheme.isChecked = true
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                binding.switchTheme.isChecked = false
            }
        }
    }

    private fun setupChangeThemeHandler() {
        val pref = SettingPreferences.getInstance(requireContext().dataStore)
        val settingViewModel = ViewModelProvider(this, SettingVMFactory(pref))[SettingVM::class.java]

        binding.switchTheme.setOnCheckedChangeListener { _: CompoundButton?, isChecked: Boolean ->
            settingViewModel.saveThemeSetting(isChecked)
        }
    }

    private fun playAnimation() {
        val userDetailCardView = ObjectAnimator.ofFloat(binding.userDetailCardView, View.ALPHA, 1f).setDuration(500)
        val settingTextView = ObjectAnimator.ofFloat(binding.tvSetting, View.ALPHA, 1f).setDuration(500)
        val themeCardView = ObjectAnimator.ofFloat(binding.themeCardView, View.ALPHA, 1f).setDuration(500)
        val languageCardView = ObjectAnimator.ofFloat(binding.languageCardView, View.ALPHA, 1f).setDuration(500)
        val logoutCardView = ObjectAnimator.ofFloat(binding.logoutCardView, View.ALPHA, 1f).setDuration(500)

        AnimatorSet().apply {
            playSequentially(userDetailCardView, settingTextView, themeCardView, languageCardView, logoutCardView)
            start()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
