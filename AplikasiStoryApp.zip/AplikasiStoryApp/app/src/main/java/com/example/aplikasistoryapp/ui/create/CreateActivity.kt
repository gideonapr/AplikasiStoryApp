package com.example.aplikasistoryapp.ui.create

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils.isEmpty
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.aplikasistoryapp.R
import com.example.aplikasistoryapp.customview.CustomAlertDialog
import com.example.aplikasistoryapp.data.Result
import com.example.aplikasistoryapp.databinding.ActivityCreatestoryBinding
import com.example.aplikasistoryapp.ui.main.MainActivity
import com.example.aplikasistoryapp.utils.VMFactory
import com.example.aplikasistoryapp.utils.createCustomTempFile
import com.example.aplikasistoryapp.utils.reduceFileImage
import com.example.aplikasistoryapp.utils.uriToFile
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class CreateActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreatestoryBinding
    private lateinit var photoFilePath: String
    private var selectedFile: File? = null
    private lateinit var viewModelFactory: VMFactory
    private val viewModel: CreateVM by viewModels { viewModelFactory }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreatestoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupViewModel()
        configureToolbar()
        requestPermissions()
        setupGalleryButton()
        setupCameraButton()
        setupSubmitButton()
    }

    private fun setupViewModel() {
        viewModelFactory = VMFactory.getInstance(applicationContext)
    }

    private fun configureToolbar() {
        title = getString(R.string.create_story)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            when {
                permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true -> { /* Permission granted */ }
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true -> { /* Permission granted */ }
                permissions[Manifest.permission.CAMERA] == true -> { /* Permission granted */ }
                permissions[Manifest.permission.READ_EXTERNAL_STORAGE] == true -> { /* Permission granted */ }
                else -> {
                    Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }

    private fun requestPermissions() {
        if (allPermissionsGranted()) {
            // All permissions are granted, proceed with action
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA
                )
            )
        }
    }

    private fun allPermissionsGranted() = listOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.CAMERA
    ).all { permission ->
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun setupGalleryButton() {
        binding.createStoryLayout.galleryButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            val chooser = Intent.createChooser(intent, "Choose a Picture")
            galleryLauncher.launch(chooser)
        }
    }

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) {
            selectedFile = File(photoFilePath)
            val bitmap = BitmapFactory.decodeFile(selectedFile!!.path)
            binding.createStoryLayout.ivAddView.setImageBitmap(bitmap)
        }
    }

    @SuppressLint("QueryPermissionsNeeded")
    private fun setupCameraButton() {
        binding.createStoryLayout.cameraButton.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            intent.resolveActivity(packageManager)
            val photoFile = createCustomTempFile(applicationContext).apply { photoFilePath = absolutePath }
            val photoURI: Uri = FileProvider.getUriForFile(this, "com.example.aplikasistoryapp.mycamera", photoFile)
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
            cameraLauncher.launch(intent)
        }
    }

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val selectedImg: Uri = result.data?.data as Uri
            selectedFile = uriToFile(selectedImg, this)
            binding.createStoryLayout.ivAddView.setImageURI(selectedImg)
        }
    }

    private fun setupSubmitButton() {
        binding.createStoryLayout.submitButton.setOnClickListener {
            val description = binding.createStoryLayout.edCreateDescription.text.toString()
            if (isInputValid(description)) {
                submitStory(description)
            } else {
                CustomAlertDialog(this, R.string.error_validation, R.drawable.formerror).show()
            }
        }
    }

    private fun isInputValid(description: String): Boolean {
        return !isEmpty(description) && selectedFile != null
    }

    private fun convertToMultipartBody(): MultipartBody.Part {
        val file = reduceFileImage(selectedFile as File)
        val requestImageFile = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
        return MultipartBody.Part.createFormData("photo", file.name, requestImageFile)
    }

    private fun convertToRequestBody(description: String): RequestBody {
        return description.toRequestBody("text/plain".toMediaType())
    }

    private fun submitStory(description: String) {
        val imagePart = convertToMultipartBody()
        val descriptionPart = convertToRequestBody(description)

        viewModel.postCreateStory(imagePart, descriptionPart, 0.1, 0.1).observe(this) { result ->
            when (result) {
                is Result.Loading -> setLoading(true)
                is Result.Error -> {
                    setLoading(false)
                    showErrorDialog()
                }
                is Result.Success -> handleSuccess()
            }
        }
    }

    private fun setLoading(isLoading: Boolean) {
        binding.loadingLayout.root.visibility = if (isLoading) View.VISIBLE else View.GONE
        binding.createStoryLayout.root.visibility = if (isLoading) View.GONE else View.VISIBLE
    }

    private fun showErrorDialog() {
        CustomAlertDialog(this, R.string.error_message, R.drawable.error).show()
    }

    private fun handleSuccess() {
        CustomAlertDialog(this, R.string.success_create_story, R.drawable.story_created) {
            navigateToMainActivity()
        }.show()
        resetInputFields()
    }

    private fun resetInputFields() {
        binding.createStoryLayout.ivAddView.setImageResource(R.drawable.imageadd)
        binding.createStoryLayout.edCreateDescription.text?.clear()
    }

    private fun navigateToMainActivity() {
        Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(this)
        }
        finish()
    }
}
