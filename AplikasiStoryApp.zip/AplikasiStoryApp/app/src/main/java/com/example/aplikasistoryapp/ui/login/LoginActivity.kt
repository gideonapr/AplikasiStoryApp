package com.example.aplikasistoryapp.ui.login

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.SpannableString
import android.text.Spanned
import android.text.TextUtils.isEmpty
import android.text.TextWatcher
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.aplikasistoryapp.R
import com.example.aplikasistoryapp.customview.CustomAlertDialog
import com.example.aplikasistoryapp.data.Result
import com.example.aplikasistoryapp.databinding.ActivityLoginBinding
import com.example.aplikasistoryapp.model.LoginResponse
import com.example.aplikasistoryapp.model.LoginResultResponse
import com.example.aplikasistoryapp.preference.LoginPreference
import com.example.aplikasistoryapp.ui.main.MainActivity
import com.example.aplikasistoryapp.ui.register.RegisterActivity
import com.example.aplikasistoryapp.utils.VMFactory
import com.example.aplikasistoryapp.utils.isValidEmail
import com.example.aplikasistoryapp.utils.validateMinLength

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var factory: VMFactory
    private val userViewModel: LoginVM by viewModels { factory }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewmodelSetup()
        runCustomAnimations()
        hideActionBar()
        buttonbasedInput()
        setupRegister()
        setupLogin()
        inputEmailHandler()
        inputPasswordHandler()
    }

    private fun viewmodelSetup() {
        factory = VMFactory.getInstance(binding.root.context)
    }

    private fun setupRegister() {
        val fullText = getString(R.string.go_regist)
        val spannableString = SpannableString(fullText)

        val clickableSpan = object : ClickableSpan() {
            override fun onClick(widget: View) {
                val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
                startActivity(intent)
            }
        }

        val startIndex = fullText.indexOf("Register")
        if (startIndex != -1) {
            val endIndex = startIndex + "Register".length
            spannableString.setSpan(clickableSpan, startIndex, endIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            binding.loginLayout.tvGoregist.text = spannableString
            binding.loginLayout.tvGoregist.movementMethod = LinkMovementMethod.getInstance()
        }
    }

    private fun setupLogin() {
        binding.loginLayout.loginButton.setOnClickListener {
            val email = binding.loginLayout.edLoginEmail.text.toString()
            val password = binding.loginLayout.edLoginPassword.text.toString()

            if (!isEmpty(email) && !isEmpty(password)) {
                handleLogin(email, password)
            } else {
                CustomAlertDialog(this, R.string.error_validation, R.drawable.formerror).show()
            }
        }
    }

    private fun handleLogin(email: String, password: String) {
        userViewModel.postLogin(email, password).observe(this@LoginActivity) { result ->
            when (result) {
                is Result.Loading -> handleLoading(true)
                is Result.Error -> {
                    handleLoading(false)
                    handleLoginError()
                }
                is Result.Success -> {
                    handleLoading(false)
                    handleLoginSuccess(result.data)
                }
            }
        }
    }

    private fun handleLoading(isLoading: Boolean) {
        binding.loadingLayout.root.visibility = if (isLoading) View.VISIBLE else View.GONE
        binding.loginLayout.root.visibility = if (isLoading) View.GONE else View.VISIBLE
    }

    private fun handleLoginSuccess(userResponse: LoginResponse) {
        saveUserData(userResponse.loginResult)
        navigateToHome()
    }

    private fun handleLoginError() {
        CustomAlertDialog(this, R.string.error_message, R.drawable.error).show()
    }

    private fun saveUserData(loginModel: LoginResultResponse?) {
        loginModel?.let {
            val userPreference = LoginPreference(this)
            userPreference.setLogin(it)
        }
    }

    private fun hideActionBar() {
        supportActionBar?.hide()
    }

    private fun navigateToHome() {
        startActivity(Intent(this@LoginActivity, MainActivity::class.java))
        finish()
    }

    private fun runCustomAnimations() {
        val animationDuration = 600L

        val emailTextView = ObjectAnimator.ofFloat(binding.loginLayout.tvEmail, View.ALPHA, 1f).setDuration(animationDuration)
        val emailTextfield = ObjectAnimator.ofFloat(binding.loginLayout.emailTextfield, View.ALPHA, 1f).setDuration(animationDuration)
        val emailEditText = ObjectAnimator.ofFloat(binding.loginLayout.edLoginEmail, View.ALPHA, 1f).setDuration(animationDuration)

        val passwordTextView = ObjectAnimator.ofFloat(binding.loginLayout.tvPassword, View.ALPHA, 1f).setDuration(animationDuration)
        val passwordTextfield = ObjectAnimator.ofFloat(binding.loginLayout.passwordTextfield, View.ALPHA, 1f).setDuration(animationDuration)
        val passwordEditText = ObjectAnimator.ofFloat(binding.loginLayout.edLoginPassword, View.ALPHA, 1f).setDuration(animationDuration)

        val loginButton = ObjectAnimator.ofFloat(binding.loginLayout.loginButton, View.ALPHA, 1f).setDuration(animationDuration)
        val registerButton = ObjectAnimator.ofFloat(binding.loginLayout.tvGoregist, View.ALPHA, 1f).setDuration(animationDuration)

        val together = AnimatorSet().apply {
            playTogether(loginButton, registerButton)
        }

        AnimatorSet().apply {
            playSequentially(
                emailTextView, emailTextfield, emailEditText,
                passwordTextView, passwordTextfield, passwordEditText, together
            )
            start()
        }
    }

    private fun buttonbasedInput() {
        binding.loginLayout.loginButton.isEnabled = isValidInput()
    }

    private fun isValidInput(): Boolean {
        val email = binding.loginLayout.edLoginEmail.text.toString()
        val password = binding.loginLayout.edLoginPassword.text.toString()
        return isValidEmail(email) && validateMinLength(password)
    }

    private fun inputEmailHandler() {
        binding.loginLayout.edLoginEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                buttonbasedInput()
            }

            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun inputPasswordHandler() {
        binding.loginLayout.edLoginPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                buttonbasedInput()
            }

            override fun afterTextChanged(s: Editable?) {}
        })
    }
}
